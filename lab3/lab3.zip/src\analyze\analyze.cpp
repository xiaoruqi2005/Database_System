/* Copyright (c) 2023 Renmin University of China
RMDB is licensed under Mulan PSL v2.
You can use this software according to the terms and conditions of the Mulan PSL v2.
You may obtain a copy of Mulan PSL v2 at:
        http://license.coscl.org.cn/MulanPSL2
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
See the Mulan PSL v2 for more details. */

#include "analyze.h"

#include <limits>

namespace {
int raw_len_for_value(const Value &value, int string_len) {
    if (value.type == TYPE_INT) {
        return sizeof(int);
    }
    if (value.type == TYPE_BIGINT) {
        return sizeof(int64_t);
    }
    if (value.type == TYPE_FLOAT) {
        return sizeof(float);
    }
    return string_len;
}
}

std::shared_ptr<Query> Analyze::do_analyze(std::shared_ptr<ast::TreeNode> parse) {
    std::shared_ptr<Query> query = std::make_shared<Query>();
    if (auto x = std::dynamic_pointer_cast<ast::SelectStmt>(parse)) {
        query->tables = std::move(x->tabs);
        for (auto &tab_name : query->tables) {
            sm_manager_->db_.get_table(tab_name);
        }

        for (auto &sv_sel_col : x->cols) {
            TabCol sel_col = {.tab_name = sv_sel_col->tab_name, .col_name = sv_sel_col->col_name};
            query->cols.push_back(sel_col);
        }

        std::vector<ColMeta> all_cols;
        get_all_cols(query->tables, all_cols);
        if (query->cols.empty()) {
            for (auto &col : all_cols) {
                TabCol sel_col = {.tab_name = col.tab_name, .col_name = col.name};
                query->cols.push_back(sel_col);
            }
        } else {
            for (auto &sel_col : query->cols) {
                sel_col = check_column(all_cols, sel_col);
            }
        }

        get_clause(x->conds, query->conds);
        check_clause(query->tables, query->conds);
    } else if (auto x = std::dynamic_pointer_cast<ast::UpdateStmt>(parse)) {
        sm_manager_->db_.get_table(x->tab_name);
        std::vector<ColMeta> all_cols;
        get_all_cols({x->tab_name}, all_cols);

        for (auto &sv_set_clause : x->set_clauses) {
            SetClause set_clause;
            set_clause.lhs = check_column(all_cols, TabCol{.tab_name = x->tab_name, .col_name = sv_set_clause->col_name});
            set_clause.rhs = convert_sv_value(sv_set_clause->val);

            TabMeta &tab = sm_manager_->db_.get_table(set_clause.lhs.tab_name);
            auto col = tab.get_col(set_clause.lhs.col_name);
            if (col->type == TYPE_FLOAT && set_clause.rhs.type == TYPE_INT) {
                set_clause.rhs.set_float(static_cast<float>(set_clause.rhs.int_val));
            }
            if (col->type == TYPE_FLOAT && set_clause.rhs.type == TYPE_BIGINT) {
                set_clause.rhs.set_float(static_cast<float>(set_clause.rhs.bigint_val));
            }
            if (col->type == TYPE_BIGINT && set_clause.rhs.type == TYPE_INT) {
                set_clause.rhs.set_bigint(static_cast<int64_t>(set_clause.rhs.int_val));
            }
            if (col->type != set_clause.rhs.type) {
                throw IncompatibleTypeError(coltype2str(col->type), coltype2str(set_clause.rhs.type));
            }
            set_clause.rhs.init_raw(col->len);
            query->set_clauses.push_back(set_clause);
        }

        get_clause(x->conds, query->conds);
        check_clause({x->tab_name}, query->conds);
    } else if (auto x = std::dynamic_pointer_cast<ast::DeleteStmt>(parse)) {
        sm_manager_->db_.get_table(x->tab_name);
        get_clause(x->conds, query->conds);
        check_clause({x->tab_name}, query->conds);
    } else if (auto x = std::dynamic_pointer_cast<ast::InsertStmt>(parse)) {
        sm_manager_->db_.get_table(x->tab_name);
        for (auto &sv_val : x->vals) {
            query->values.push_back(convert_sv_value(sv_val));
        }
    }

    query->parse = std::move(parse);
    return query;
}

TabCol Analyze::check_column(const std::vector<ColMeta> &all_cols, TabCol target) {
    if (target.tab_name.empty()) {
        std::string tab_name;
        for (auto &col : all_cols) {
            if (col.name == target.col_name) {
                if (!tab_name.empty()) {
                    throw AmbiguousColumnError(target.col_name);
                }
                tab_name = col.tab_name;
            }
        }
        if (tab_name.empty()) {
            throw ColumnNotFoundError(target.col_name);
        }
        target.tab_name = tab_name;
    } else {
        TabMeta &tab = sm_manager_->db_.get_table(target.tab_name);
        tab.get_col(target.col_name);
    }
    return target;
}

void Analyze::get_all_cols(const std::vector<std::string> &tab_names, std::vector<ColMeta> &all_cols) {
    for (auto &sel_tab_name : tab_names) {
        const auto &sel_tab_cols = sm_manager_->db_.get_table(sel_tab_name).cols;
        all_cols.insert(all_cols.end(), sel_tab_cols.begin(), sel_tab_cols.end());
    }
}

void Analyze::get_clause(const std::vector<std::shared_ptr<ast::BinaryExpr>> &sv_conds,
                         std::vector<Condition> &conds) {
    conds.clear();
    for (auto &expr : sv_conds) {
        Condition cond;
        cond.lhs_col = {.tab_name = expr->lhs->tab_name, .col_name = expr->lhs->col_name};
        cond.op = convert_sv_comp_op(expr->op);
        if (auto rhs_val = std::dynamic_pointer_cast<ast::Value>(expr->rhs)) {
            cond.is_rhs_val = true;
            cond.rhs_val = convert_sv_value(rhs_val);
        } else if (auto rhs_col = std::dynamic_pointer_cast<ast::Col>(expr->rhs)) {
            cond.is_rhs_val = false;
            cond.rhs_col = {.tab_name = rhs_col->tab_name, .col_name = rhs_col->col_name};
        }
        conds.push_back(cond);
    }
}

void Analyze::check_clause(const std::vector<std::string> &tab_names, std::vector<Condition> &conds) {
    std::vector<ColMeta> all_cols;
    get_all_cols(tab_names, all_cols);
    for (auto &cond : conds) {
        cond.lhs_col = check_column(all_cols, cond.lhs_col);
        if (!cond.is_rhs_val) {
            cond.rhs_col = check_column(all_cols, cond.rhs_col);
        }

        TabMeta &lhs_tab = sm_manager_->db_.get_table(cond.lhs_col.tab_name);
        auto lhs_col = lhs_tab.get_col(cond.lhs_col.col_name);
        ColType lhs_type = lhs_col->type;
        ColType rhs_type;
        if (cond.is_rhs_val) {
            if (lhs_type == TYPE_FLOAT && cond.rhs_val.type == TYPE_INT) {
                cond.rhs_val.set_float(static_cast<float>(cond.rhs_val.int_val));
            }
            if (lhs_type == TYPE_FLOAT && cond.rhs_val.type == TYPE_BIGINT) {
                cond.rhs_val.set_float(static_cast<float>(cond.rhs_val.bigint_val));
            }
            if (lhs_type == TYPE_BIGINT && cond.rhs_val.type == TYPE_INT) {
                cond.rhs_val.set_bigint(static_cast<int64_t>(cond.rhs_val.int_val));
            }
            cond.rhs_val.init_raw(raw_len_for_value(cond.rhs_val, lhs_col->len));
            rhs_type = cond.rhs_val.type;
        } else {
            TabMeta &rhs_tab = sm_manager_->db_.get_table(cond.rhs_col.tab_name);
            auto rhs_col = rhs_tab.get_col(cond.rhs_col.col_name);
            rhs_type = rhs_col->type;
        }

        bool lhs_numeric = lhs_type == TYPE_INT || lhs_type == TYPE_FLOAT || lhs_type == TYPE_BIGINT;
        bool rhs_numeric = rhs_type == TYPE_INT || rhs_type == TYPE_FLOAT || rhs_type == TYPE_BIGINT;
        if (lhs_type != rhs_type && !(lhs_numeric && rhs_numeric)) {
            throw IncompatibleTypeError(coltype2str(lhs_type), coltype2str(rhs_type));
        }
    }
}

Value Analyze::convert_sv_value(const std::shared_ptr<ast::Value> &sv_val) {
    Value val;
    if (auto int_lit = std::dynamic_pointer_cast<ast::IntLit>(sv_val)) {
        try {
            long long int_val = std::stoll(int_lit->val);
            if (int_val >= std::numeric_limits<int>::min() && int_val <= std::numeric_limits<int>::max()) {
                val.set_int(static_cast<int>(int_val));
            } else {
                val.set_bigint(static_cast<int64_t>(int_val));
            }
        } catch (const std::exception &) {
            throw InternalError("BIGINT value out of range");
        }
    } else if (auto float_lit = std::dynamic_pointer_cast<ast::FloatLit>(sv_val)) {
        val.set_float(float_lit->val);
    } else if (auto str_lit = std::dynamic_pointer_cast<ast::StringLit>(sv_val)) {
        val.set_str(str_lit->val);
    } else {
        throw InternalError("Unexpected sv value type");
    }
    return val;
}

CompOp Analyze::convert_sv_comp_op(ast::SvCompOp op) {
    std::map<ast::SvCompOp, CompOp> m = {
        {ast::SV_OP_EQ, OP_EQ}, {ast::SV_OP_NE, OP_NE}, {ast::SV_OP_LT, OP_LT},
        {ast::SV_OP_GT, OP_GT}, {ast::SV_OP_LE, OP_LE}, {ast::SV_OP_GE, OP_GE},
    };
    return m.at(op);
}
