/* Copyright (c) 2023 Renmin University of China
RMDB is licensed under Mulan PSL v2.
You can use this software according to the terms and conditions of the Mulan PSL v2.
You may obtain a copy of Mulan PSL v2 at:
        http://license.coscl.org.cn/MulanPSL2
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
See the Mulan PSL v2 for more details. */

#include "sm_manager.h"

#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <sstream>

#include "index/ix.h"
#include "record/rm.h"
#include "record/rm_scan.h"
#include "record_printer.h"

/**
 * @description: 判断是否为一个文件夹
 * @return {bool} 返回是否为一个文件夹
 * @param {string&} db_name 数据库文件名称，与文件夹同名
 */
bool SmManager::is_dir(const std::string& db_name) {
    struct stat st;
    return stat(db_name.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

/**
 * @description: 创建数据库，所有的数据库相关文件都放在数据库同名文件夹下
 * @param {string&} db_name 数据库名称
 */
void SmManager::create_db(const std::string& db_name) {
    if (is_dir(db_name)) {
        throw DatabaseExistsError(db_name);
    }
    //为数据库创建一个子目录
    std::string cmd = "mkdir " + db_name;
    if (system(cmd.c_str()) < 0) {  // 创建一个名为db_name的目录
        throw UnixError();
    }
    if (chdir(db_name.c_str()) < 0) {  // 进入名为db_name的目录
        throw UnixError();
    }
    //创建系统目录
    DbMeta *new_db = new DbMeta();
    new_db->name_ = db_name;

    // 注意，此处ofstream会在当前目录创建(如果没有此文件先创建)和打开一个名为DB_META_NAME的文件
    std::ofstream ofs(DB_META_NAME);

    // 将new_db中的信息，按照定义好的operator<<操作符，写入到ofs打开的DB_META_NAME文件中
    ofs << *new_db;  // 注意：此处重载了操作符<<

    delete new_db;

    // 创建日志文件
    disk_manager_->create_file(LOG_FILE_NAME);

    // 回到根目录
    if (chdir("..") < 0) {
        throw UnixError();
    }
}

/**
 * @description: 删除数据库，同时需要清空相关文件以及数据库同名文件夹
 * @param {string&} db_name 数据库名称，与文件夹同名
 */
void SmManager::drop_db(const std::string& db_name) {
    if (!is_dir(db_name)) {
        throw DatabaseNotFoundError(db_name);
    }
    std::string cmd = "rm -r " + db_name;
    if (system(cmd.c_str()) < 0) {
        throw UnixError();
    }
}

/**
 * @description: 打开数据库，找到数据库对应的文件夹，并加载数据库元数据和相关文件
 * @param {string&} db_name 数据库名称，与文件夹同名
 */
void SmManager::open_db(const std::string& db_name) {
    if (!is_dir(db_name)) {
        throw DatabaseNotFoundError(db_name);
    }
    if (chdir(db_name.c_str()) < 0) {
        throw UnixError();
    }

    std::ifstream ifs(DB_META_NAME);
    if (!ifs.is_open()) {
        throw FileNotFoundError(DB_META_NAME);
    }
    ifs >> db_;

    fhs_.clear();
    ihs_.clear();
    memory_indexes_.clear();
    for (auto &entry : db_.tabs_) {
        fhs_.emplace(entry.first, rm_manager_->open_file(entry.first));
    }
    rebuild_all_memory_indexes();

    std::ofstream outfile("output.txt", std::ios::out | std::ios::trunc);
}

/**
 * @description: 把数据库相关的元数据刷入磁盘中
 */
void SmManager::flush_meta() {
    // 默认清空文件
    std::ofstream ofs(DB_META_NAME);
    ofs << db_;
}

/**
 * @description: 关闭数据库并把数据落盘
 */
void SmManager::close_db() {
    flush_meta();
    for (auto &entry : ihs_) {
        ix_manager_->close_index(entry.second.get());
    }
    ihs_.clear();
    for (auto &entry : fhs_) {
        rm_manager_->close_file(entry.second.get());
    }
    fhs_.clear();
    if (disk_manager_->is_file(LOG_FILE_NAME) && disk_manager_->GetLogFd() != -1) {
        disk_manager_->close_file(disk_manager_->GetLogFd());
        disk_manager_->SetLogFd(-1);
    }
    if (chdir("..") < 0) {
        throw UnixError();
    }
}

/**
 * @description: 显示所有的表,通过测试需要将其结果写入到output.txt,详情看题目文档
 * @param {Context*} context 
 */
void SmManager::show_tables(Context* context) {
    std::fstream outfile;
    outfile.open("output.txt", std::ios::out | std::ios::app);
    outfile << "| Tables |\n";
    RecordPrinter printer(1);
    printer.print_separator(context);
    printer.print_record({"Tables"}, context);
    printer.print_separator(context);
    for (auto &entry : db_.tabs_) {
        auto &tab = entry.second;
        printer.print_record({tab.name}, context);
        outfile << "| " << tab.name << " |\n";
    }
    printer.print_separator(context);
    outfile.close();
}

/**
 * @description: 显示表的元数据
 * @param {string&} tab_name 表名称
 * @param {Context*} context 
 */
void SmManager::desc_table(const std::string& tab_name, Context* context) {
    TabMeta &tab = db_.get_table(tab_name);

    std::vector<std::string> captions = {"Field", "Type", "Index"};
    RecordPrinter printer(captions.size());
    // Print header
    printer.print_separator(context);
    printer.print_record(captions, context);
    printer.print_separator(context);
    // Print fields
    for (auto &col : tab.cols) {
        std::vector<std::string> field_info = {col.name, coltype2str(col.type), col.index ? "YES" : "NO"};
        printer.print_record(field_info, context);
    }
    // Print footer
    printer.print_separator(context);
}

/**
 * @description: 创建表
 * @param {string&} tab_name 表的名称
 * @param {vector<ColDef>&} col_defs 表的字段
 * @param {Context*} context 
 */
void SmManager::create_table(const std::string& tab_name, const std::vector<ColDef>& col_defs, Context* context) {
    if (db_.is_table(tab_name)) {
        throw TableExistsError(tab_name);
    }
    // Create table meta
    int curr_offset = 0;
    TabMeta tab;
    tab.name = tab_name;
    for (auto &col_def : col_defs) {
        ColMeta col = {.tab_name = tab_name,
                       .name = col_def.name,
                       .type = col_def.type,
                       .len = col_def.len,
                       .offset = curr_offset,
                       .index = false};
        curr_offset += col_def.len;
        tab.cols.push_back(col);
    }
    // Create & open record file
    int record_size = curr_offset;  // record_size就是col meta所占的大小（表的元数据也是以记录的形式进行存储的）
    rm_manager_->create_file(tab_name, record_size);
    db_.tabs_[tab_name] = tab;
    // fhs_[tab_name] = rm_manager_->open_file(tab_name);
    fhs_.emplace(tab_name, rm_manager_->open_file(tab_name));

    flush_meta();
}

/**
 * @description: 删除表
 * @param {string&} tab_name 表的名称
 * @param {Context*} context
 */
void SmManager::drop_table(const std::string& tab_name, Context* context) {
    if (!db_.is_table(tab_name)) {
        throw TableNotFoundError(tab_name);
    }
    auto fh_it = fhs_.find(tab_name);
    if (fh_it != fhs_.end()) {
        rm_manager_->close_file(fh_it->second.get());
        fhs_.erase(fh_it);
    }

    auto &tab = db_.get_table(tab_name);
    for (auto &index : tab.indexes) {
        memory_indexes_.erase(make_index_name(tab_name, index.cols));
    }

    rm_manager_->destroy_file(tab_name);
    db_.tabs_.erase(tab_name);
    flush_meta();
}

/**
 * @description: 创建索引
 * @param {string&} tab_name 表的名称
 * @param {vector<string>&} col_names 索引包含的字段名称
 * @param {Context*} context
 */
void SmManager::create_index(const std::string& tab_name, const std::vector<std::string>& col_names, Context* context) {
    if (!db_.is_table(tab_name)) {
        throw TableNotFoundError(tab_name);
    }
    TabMeta &tab = db_.get_table(tab_name);
    if (tab.is_index(col_names)) {
        throw IndexExistsError(tab_name, col_names);
    }

    IndexMeta index;
    index.tab_name = tab_name;
    index.col_tot_len = 0;
    index.col_num = static_cast<int>(col_names.size());
    for (auto &col_name : col_names) {
        auto col = tab.get_col(col_name);
        index.cols.push_back(*col);
        index.col_tot_len += col->len;
    }

    tab.indexes.push_back(index);
    for (auto &col_name : col_names) {
        tab.get_col(col_name)->index = true;
    }
    try {
        rebuild_memory_index(tab_name, index);
    } catch (...) {
        tab.indexes.pop_back();
        for (auto &col : tab.cols) {
            col.index = false;
        }
        for (auto &idx : tab.indexes) {
            for (auto &idx_col : idx.cols) {
                tab.get_col(idx_col.name)->index = true;
            }
        }
        throw;
    }
    flush_meta();
}

/**
 * @description: 删除索引
 * @param {string&} tab_name 表名称
 * @param {vector<string>&} col_names 索引包含的字段名称
 * @param {Context*} context
 */
void SmManager::drop_index(const std::string& tab_name, const std::vector<std::string>& col_names, Context* context) {
    if (!db_.is_table(tab_name)) {
        throw TableNotFoundError(tab_name);
    }
    TabMeta &tab = db_.get_table(tab_name);
    auto index_it = tab.get_index_meta(col_names);
    memory_indexes_.erase(make_index_name(tab_name, index_it->cols));
    tab.indexes.erase(index_it);

    for (auto &col : tab.cols) {
        col.index = false;
    }
    for (auto &index : tab.indexes) {
        for (auto &col : index.cols) {
            tab.get_col(col.name)->index = true;
        }
    }
    flush_meta();
}

/**
 * @description: 删除索引
 * @param {string&} tab_name 表名称
 * @param {vector<ColMeta>&} 索引包含的字段元数据
 * @param {Context*} context
 */
void SmManager::drop_index(const std::string& tab_name, const std::vector<ColMeta>& cols, Context* context) {
    std::vector<std::string> col_names;
    for (auto &col : cols) {
        col_names.push_back(col.name);
    }
    drop_index(tab_name, col_names, context);
}

namespace {
int compare_key_part(const char *lhs, const char *rhs, const ColMeta &col) {
    if (col.type == TYPE_INT) {
        int lval = *reinterpret_cast<const int *>(lhs);
        int rval = *reinterpret_cast<const int *>(rhs);
        return (lval > rval) - (lval < rval);
    }
    if (col.type == TYPE_BIGINT || col.type == TYPE_DATETIME) {
        int64_t lval = *reinterpret_cast<const int64_t *>(lhs);
        int64_t rval = *reinterpret_cast<const int64_t *>(rhs);
        return (lval > rval) - (lval < rval);
    }
    if (col.type == TYPE_FLOAT) {
        float lval = *reinterpret_cast<const float *>(lhs);
        float rval = *reinterpret_cast<const float *>(rhs);
        if (std::abs(lval - rval) <= 1e-6f) {
            return 0;
        }
        return (lval > rval) - (lval < rval);
    }
    return std::strncmp(lhs, rhs, col.len);
}

bool compare_by_op(int cmp, CompOp op) {
    switch (op) {
        case OP_EQ: return cmp == 0;
        case OP_NE: return cmp != 0;
        case OP_LT: return cmp < 0;
        case OP_GT: return cmp > 0;
        case OP_LE: return cmp <= 0;
        case OP_GE: return cmp >= 0;
    }
    return false;
}

bool same_rid(const Rid &lhs, const Rid &rhs) {
    return lhs.page_no == rhs.page_no && lhs.slot_no == rhs.slot_no;
}

int index_key_offset(const IndexMeta &index, const std::string &col_name) {
    int offset = 0;
    for (auto &col : index.cols) {
        if (col.name == col_name) {
            return offset;
        }
        offset += col.len;
    }
    return -1;
}
}  // namespace

std::string SmManager::make_index_name(const std::string& tab_name, const std::vector<ColMeta>& cols) const {
    std::string index_name = tab_name;
    for (auto &col : cols) {
        index_name += "_" + col.name;
    }
    return index_name;
}

std::string SmManager::build_index_key(const IndexMeta& index, const char* record_data) const {
    std::string key;
    key.resize(index.col_tot_len);
    int offset = 0;
    for (auto &col : index.cols) {
        memcpy(&key[offset], record_data + col.offset, col.len);
        offset += col.len;
    }
    return key;
}

void SmManager::rebuild_memory_index(const std::string& tab_name, const IndexMeta& index) {
    auto fh = fhs_.at(tab_name).get();
    std::string index_name = make_index_name(tab_name, index.cols);
    std::vector<MemoryIndexEntry> entries;
    for (RmScan scan(fh); !scan.is_end(); scan.next()) {
        Rid rid = scan.rid();
        auto rec = fh->get_record(rid, nullptr);
        std::string key = build_index_key(index, rec->data);
        auto dup = std::find_if(entries.begin(), entries.end(), [&](const MemoryIndexEntry &entry) {
            return entry.key == key;
        });
        if (dup != entries.end()) {
            throw InternalError("Duplicate key");
        }
        entries.push_back({key, rid});
    }
    memory_indexes_[index_name] = std::move(entries);
}

void SmManager::rebuild_all_memory_indexes() {
    memory_indexes_.clear();
    for (auto &entry : db_.tabs_) {
        for (auto &index : entry.second.indexes) {
            rebuild_memory_index(entry.first, index);
        }
    }
}

void SmManager::check_unique_memory_indexes(const std::string& tab_name, const char* record_data, const Rid* self) {
    TabMeta &tab = db_.get_table(tab_name);
    for (auto &index : tab.indexes) {
        std::string index_name = make_index_name(tab_name, index.cols);
        if (memory_indexes_.find(index_name) == memory_indexes_.end()) {
            rebuild_memory_index(tab_name, index);
        }
        std::string key = build_index_key(index, record_data);
        for (auto &entry : memory_indexes_[index_name]) {
            if (entry.key == key && (self == nullptr || !same_rid(entry.rid, *self))) {
                throw InternalError("Duplicate key");
            }
        }
    }
}

void SmManager::insert_into_memory_indexes(const std::string& tab_name, const char* record_data, const Rid& rid) {
    TabMeta &tab = db_.get_table(tab_name);
    for (auto &index : tab.indexes) {
        std::string index_name = make_index_name(tab_name, index.cols);
        memory_indexes_[index_name].push_back({build_index_key(index, record_data), rid});
    }
}

void SmManager::delete_from_memory_indexes(const std::string& tab_name, const char* record_data, const Rid& rid) {
    TabMeta &tab = db_.get_table(tab_name);
    for (auto &index : tab.indexes) {
        std::string index_name = make_index_name(tab_name, index.cols);
        std::string key = build_index_key(index, record_data);
        auto &entries = memory_indexes_[index_name];
        entries.erase(std::remove_if(entries.begin(), entries.end(), [&](const MemoryIndexEntry &entry) {
            return entry.key == key && same_rid(entry.rid, rid);
        }), entries.end());
    }
}

void SmManager::update_memory_indexes(const std::string& tab_name, const char* old_data, const char* new_data, const Rid& rid) {
    delete_from_memory_indexes(tab_name, old_data, rid);
    insert_into_memory_indexes(tab_name, new_data, rid);
}

std::vector<Rid> SmManager::scan_memory_index(const std::string& tab_name, const std::vector<std::string>& index_col_names,
                                              const std::vector<Condition>& conds) {
    TabMeta &tab = db_.get_table(tab_name);
    IndexMeta index = *tab.get_index_meta(index_col_names);
    std::string index_name = make_index_name(tab_name, index.cols);
    if (memory_indexes_.find(index_name) == memory_indexes_.end()) {
        rebuild_memory_index(tab_name, index);
    }

    std::vector<Rid> result;
    for (auto &entry : memory_indexes_[index_name]) {
        bool ok = true;
        for (auto &cond : conds) {
            if (!cond.is_rhs_val || cond.lhs_col.tab_name != tab_name) {
                continue;
            }
            int key_offset = index_key_offset(index, cond.lhs_col.col_name);
            if (key_offset < 0) {
                continue;
            }
            auto idx_col = std::find_if(index.cols.begin(), index.cols.end(), [&](const ColMeta &col) {
                return col.name == cond.lhs_col.col_name;
            });
            if (idx_col == index.cols.end()) {
                continue;
            }
            int cmp = compare_key_part(entry.key.data() + key_offset, cond.rhs_val.raw->data, *idx_col);
            if (!compare_by_op(cmp, cond.op)) {
                ok = false;
                break;
            }
        }
        if (ok) {
            result.push_back(entry.rid);
        }
    }
    return result;
}

void SmManager::show_index(const std::string& tab_name, Context* context) {
    if (!db_.is_table(tab_name)) {
        throw TableNotFoundError(tab_name);
    }
    TabMeta &tab = db_.get_table(tab_name);
    std::stringstream ss;
    for (auto &index : tab.indexes) {
        ss << "| " << tab_name << " | unique | (";
        for (int i = 0; i < index.col_num; ++i) {
            if (i > 0) {
                ss << ",";
            }
            ss << index.cols[i].name;
        }
        ss << ") |\n";
    }
    std::string output = ss.str();
    std::fstream outfile("output.txt", std::ios::out | std::ios::app);
    outfile << output;
    outfile.close();
    if (context != nullptr && context->data_send_ != nullptr && context->offset_ != nullptr) {
        memcpy(context->data_send_, output.c_str(), output.size());
        context->data_send_[output.size()] = '\0';
        *context->offset_ = static_cast<int>(output.size());
    }
}
